return {
  "numToStr/Comment.nvim",
  config = function()
    require("Comment").setup()
    lazy = false
    opts = {
      -- options
    }
  end,
}
