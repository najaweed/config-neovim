return {
	"VonHeikemen/fine-cmdline.nvim",
	config = function()
		requires = { "MunifTanjim/nui.nvim" }
	end,
}
